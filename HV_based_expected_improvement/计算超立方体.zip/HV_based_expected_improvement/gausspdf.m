function res=gausspdf(x)
    res=1/sqrt(2*pi)*exp(-x^2/2);